import model.Usuario;

public class Main {
    public static void main(String[] args) throws Exception {
        Usuario.adicionarUsuariosTestes();
        Usuario.menu();
    }
}
